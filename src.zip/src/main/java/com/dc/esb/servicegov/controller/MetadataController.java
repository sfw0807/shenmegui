package com.dc.esb.servicegov.controller;

import com.dc.esb.servicegov.dao.support.Page;
import com.dc.esb.servicegov.entity.CategoryWord;
import com.dc.esb.servicegov.entity.Metadata;
import com.dc.esb.servicegov.export.impl.MetadataConfigGenerator;
import com.dc.esb.servicegov.service.impl.MetadataServiceImpl;
import org.apache.commons.logging.Log;
import org.apache.commons.logging.LogFactory;
import org.apache.shiro.SecurityUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.ModelAndView;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.*;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Controller
@RequestMapping("/metadata")
public class MetadataController {

    private static final Log log = LogFactory.getLog(MetadataController.class);
    @Autowired
    private MetadataServiceImpl metadataService;

    @Autowired
    private MetadataConfigGenerator metadataConfigGenerator;

    @RequestMapping(method = RequestMethod.GET, value = "/getAll", headers = "Accept=application/json")
    public
    @ResponseBody
    List<Metadata> getAll() {
        return metadataService.getAllMetadata();
    }

    @RequestMapping(method = RequestMethod.GET, value = "/getByMetadataId/{metadataId}", headers = "Accept=application/json")
    public
    @ResponseBody
    List<Metadata> getByMetadataId(@PathVariable(value = "metadataId") String metadataId) {
        return metadataService.getByMetadataId(metadataId);
    }

    @RequestMapping(method = RequestMethod.GET, value = "/getByMetadataName/{metadataName}", headers = "Accept=application/json")
    public
    @ResponseBody
    List<Metadata> getByMetadataName(@PathVariable(value = "metadataName") String metadataName) {
        return metadataService.getByMetadataName(metadataName);
    }

    @RequestMapping(method = RequestMethod.GET, value = "/getByChineseName/{chineseName}", headers = "Accept=application/json")
    public
    @ResponseBody
    List<Metadata> getByChineseName(@PathVariable(value = "chineseName") String chineseName) {
        return metadataService.getByChineseName(chineseName);
    }

    @RequestMapping(method = RequestMethod.GET, value = "/getByCategoryWordId/{categoryWordId}", headers = "Accept=application/json")
    public
    @ResponseBody
    List<Metadata> getByCategoryWordId(@PathVariable(value = "categoryWordId") String categoryWordId) {
        return metadataService.getByCategoryWordId(categoryWordId);
    }

    @RequestMapping(method = RequestMethod.GET, value = "/getByRemark/{remark}", headers = "Accept=application/json")
    public
    @ResponseBody
    List<Metadata> getByRemark(@PathVariable(value = "remark") String remark) {
        return metadataService.getByRemark(remark);
    }

    @RequestMapping(method = RequestMethod.GET, value = "/getByType/{type}", headers = "Accept=application/json")
    public
    @ResponseBody
    List<Metadata> getByType(@PathVariable(value = "type") String type) {
        return metadataService.getByType(type);
    }

    @RequestMapping(method = RequestMethod.GET, value = "/getByLength/{length}", headers = "Accept=application/json")
    public
    @ResponseBody
    List<Metadata> getByLength(@PathVariable(value = "length") String length) {
        return metadataService.getByLength(length);
    }

    @RequestMapping(method = RequestMethod.GET, value = "/getByScale/{scale}", headers = "Accept=application/json")
    public
    @ResponseBody
    List<Metadata> getByScale(@PathVariable(value = "scale") String scale) {
        return metadataService.getByScale(scale);
    }

    @RequestMapping(method = RequestMethod.GET, value = "/getByEnumId/{enumId}", headers = "Accept=application/json")
    public
    @ResponseBody
    List<Metadata> getByEnumId(@PathVariable(value = "enumId") String enumId) {
        return metadataService.getByEnumId(enumId);
    }

    @RequestMapping(method = RequestMethod.GET, value = "/getByMetadataAlias/{metadataAlias}", headers = "Accept=application/json")
    public
    @ResponseBody
    List<Metadata> getByMetadataAlias(@PathVariable(value = "metadataAlias") String metadataAlias) {
        return metadataService.getByMetadataAlias(metadataAlias);
    }

    @RequestMapping(method = RequestMethod.GET, value = "/getByBussDefine/{bussDefine}", headers = "Accept=application/json")
    public
    @ResponseBody
    List<Metadata> getByBussDefine(@PathVariable(value = "bussDefine") String bussDefine) {
        return metadataService.getByBussDefine(bussDefine);
    }

    @RequestMapping(method = RequestMethod.GET, value = "/getByBussRule/{bussRule}", headers = "Accept=application/json")
    public
    @ResponseBody
    List<Metadata> getByBussRule(@PathVariable(value = "bussRule") String bussRule) {
        return metadataService.getByBussRule(bussRule);
    }

    @RequestMapping(method = RequestMethod.GET, value = "/getByDataSource/{dataSource}", headers = "Accept=application/json")
    public
    @ResponseBody
    List<Metadata> getByDataSource(@PathVariable(value = "dataSource") String dataSource) {
        return metadataService.getByDataSource(dataSource);
    }

    @RequestMapping(method = RequestMethod.GET, value = "/getByTemplateId/{templateId}", headers = "Accept=application/json")
    public
    @ResponseBody
    List<Metadata> getByTemplateId(@PathVariable(value = "templateId") String templateId) {
        return metadataService.getByTemplateId(templateId);
    }

    @RequestMapping(method = RequestMethod.GET, value = "/getByStatus/{status}", headers = "Accept=application/json")
    public
    @ResponseBody
    List<Metadata> getByStatus(@PathVariable(value = "status") String status) {
        return metadataService.getByStatus(status);
    }

    @RequestMapping(method = RequestMethod.GET, value = "/getByVersion/{version}", headers = "Accept=application/json")
    public
    @ResponseBody
    List<Metadata> getByVersion(@PathVariable(value = "version") String version) {
        return metadataService.getByVersion(version);
    }

    @RequestMapping(method = RequestMethod.GET, value = "/getByPotUser/{potUser}", headers = "Accept=application/json")
    public
    @ResponseBody
    List<Metadata> getByPotUser(@PathVariable(value = "potUser") String potUser) {
        return metadataService.getByPotUser(potUser);
    }

    @RequestMapping(method = RequestMethod.GET, value = "/getByPotDate/{potDate}", headers = "Accept=application/json")
    public
    @ResponseBody
    List<Metadata> getByPotDate(@PathVariable(value = "potDate") String potDate) {
        return metadataService.getByPotDate(potDate);
    }

    @RequestMapping(method = RequestMethod.GET, value = "/getByAuditUser/{auditUser}", headers = "Accept=application/json")
    public
    @ResponseBody
    List<Metadata> getByAuditUser(@PathVariable(value = "auditUser") String auditUser) {
        return metadataService.getByAuditUser(auditUser);
    }

    @RequestMapping(method = RequestMethod.GET, value = "/getByAuditDate/{auditDate}", headers = "Accept=application/json")
    public
    @ResponseBody
    List<Metadata> getByAuditDate(@PathVariable(value = "auditDate") String auditDate) {
        return metadataService.getByAuditDate(auditDate);
    }

    @RequestMapping(method = RequestMethod.POST, value = "/add", headers = "Accept=application/json")
    public
    @ResponseBody
    boolean add(Metadata metadata) {
        metadataService.addMetadata(metadata);
        return true;
    }

    @RequestMapping(method = RequestMethod.POST, value = "/modify", headers = "Accept=application/json")
    public
    @ResponseBody
    boolean modify(Metadata metadata) {
        metadataService.modifyMetadata(metadata);
        return true;
    }

    @RequestMapping(method = RequestMethod.DELETE, value = "/delete/{metadataId}", headers = "Accept=application/json")
    public
    @ResponseBody
    boolean delete(@PathVariable String metadataId) {
        metadataService.deleteMetadata(metadataId);
        return true;
    }

    @RequestMapping("/deletes")
    @ResponseBody
    public boolean deletes(String metadataIds) {
        metadataService.deleteMetadatas(metadataIds);
        return true;
    }

    @RequestMapping("/list")
    @ResponseBody
    public Map<String, Object> list(@RequestParam("page") int pageNo, @RequestParam("rows") int rowCount) {
        Page page = metadataService.getAll(rowCount);
        page.setPage(pageNo);
        List<Metadata> rows = metadataService.getAll(page);
        Map<String, Object> result = new HashMap<String, Object>();
        result.put("total", page.getResultCount());
        result.put("rows", rows);
        return result;
    }

    @RequestMapping(method = RequestMethod.POST, value = "/query", headers = "Accept=application/json" )
    @ResponseBody
    public Map<String, Object> query(@RequestBody Map<String, String> params) {
        List<Metadata> rows = metadataService.findLikeAnyWhere(params);
        Map<String, Object> result = new HashMap<String, Object>();
        result.put("total", rows.size());
        result.put("rows", rows);
        return result;
    }

    @RequestMapping("/query/processId/{processId}")
    @ResponseBody
    public Map<String, Object> query(HttpServletRequest request, @PathVariable("processId") String processId) {

        Map<String, Object> result = new HashMap<String, Object>();
        Map<String, String> params = new HashMap<String, String>();
        params.put("processId", processId);
        List<Metadata> rows = metadataService.findBy(params);

        result.put("total", rows.size());
        result.put("rows", rows);
        return result;
    }

    @RequestMapping(method = RequestMethod.GET, value = "/editPage", headers = "Accept=application/json")
    public ModelAndView editPage(String metadataId) {
        ModelAndView mv = new ModelAndView("../assets/metadata/edit");
        List<Metadata> list = metadataService.getByMetadataId(metadataId);
        if (list != null && list.size() > 0) {
            Metadata entity = list.get(0);
            mv.addObject("entity", entity);
        }

        return mv;
    }

    @RequestMapping(method = RequestMethod.GET, value = "/uniqueValid", headers = "Accept=application/json")
    public
    @ResponseBody
    boolean uniqueValid(String metadataId) {
        return metadataService.uniqueValid(metadataId);
    }

    //获取类别词接口
    @RequestMapping("/categoryWord")
    @ResponseBody
    public List<CategoryWord> categoryWord() {

        List<CategoryWord> rows = metadataService.categoryWord();

        return rows;
    }

    @RequestMapping("/servicePage")
    public ModelAndView servicePage(String serviceId) {
        ModelAndView mv = new ModelAndView("service/serviceIndex");
        return mv;
    }

    @RequestMapping("/audit/process/{processId}")
    public @ResponseBody boolean auditMetadata(@PathVariable("processId") String processId){
        Map<String, String> params = new HashMap<String, String>();
        params.put("processId", processId);
        List<Metadata> metadatas = metadataService.findBy(params);
        for(Metadata metadata : metadatas){
            metadata.setStatus("正式");
            metadataService.save(metadata);
        }
        return true;
    }


    @RequestMapping(method = RequestMethod.GET, value = "/export")
    public @ResponseBody
    boolean exportMetadata(HttpServletRequest request, HttpServletResponse response){
        log.info( SecurityUtils.getSubject().getPrincipal());
        //生成本地文件
        File file = metadataConfigGenerator.generate();
        //读取本地文件内容
        int length = (int) file.length();
        DataInputStream dataIn = null;
        OutputStream out = null;
        try {
            dataIn = new DataInputStream(new FileInputStream(file));
            byte[] buffer = new byte[length];
            dataIn.readFully(buffer);
            //修改HTTP头
            response.setContentType("application/octet-stream");
            response.addHeader("Content-Disposition",
                    "attachment;filename="
                            + new String(file.getName().getBytes(
                            "gbk"), "iso-8859-1"));
            //把本地文件的内容写入Http输出流
            out = response.getOutputStream();
            out.write(buffer);
        } catch (Exception e) {
            e.printStackTrace();
        }finally{
            if(null != dataIn){
                try {
                    dataIn.close();
                } catch (IOException e) {
                    log.error(e, e);
                }
                try {
                    out.close();
                } catch (IOException e) {
                    log.error(e, e);
                }
            }
        }
        //删除本地文件
        file.delete();
        return true;
    }
}

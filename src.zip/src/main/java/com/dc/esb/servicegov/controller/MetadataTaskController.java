package com.dc.esb.servicegov.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

/**
 * Created by vincentfxz on 15/7/6.
 */
@Controller
@RequestMapping("process")
public class MetadataTaskController {

}

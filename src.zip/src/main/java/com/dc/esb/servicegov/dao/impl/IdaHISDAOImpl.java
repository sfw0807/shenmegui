package com.dc.esb.servicegov.dao.impl;

import com.dc.esb.servicegov.dao.support.HibernateDAO;
import org.springframework.stereotype.Repository;

import com.dc.esb.servicegov.entity.IdaHIS;


@Repository
public class IdaHISDAOImpl extends HibernateDAO<IdaHIS, String> {

}
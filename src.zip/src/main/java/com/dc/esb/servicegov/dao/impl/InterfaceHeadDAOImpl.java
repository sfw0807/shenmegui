package com.dc.esb.servicegov.dao.impl;

import com.dc.esb.servicegov.dao.support.HibernateDAO;
import org.springframework.stereotype.Repository;

import com.dc.esb.servicegov.entity.InterfaceHead;

@Repository
public class InterfaceHeadDAOImpl extends HibernateDAO<InterfaceHead, String> {

}
package com.dc.esb.servicegov.dao.impl;

import org.springframework.stereotype.Repository;

import com.dc.esb.servicegov.dao.support.HibernateDAO;
import com.dc.esb.servicegov.entity.OLATemplate;
@Repository
public class OLATemplateDAOImpl extends HibernateDAO<OLATemplate, String> {
	

}


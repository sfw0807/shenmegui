package com.dc.esb.servicegov.dao.impl;

import org.springframework.stereotype.Repository;

import com.dc.esb.servicegov.dao.support.HibernateDAO;
import com.dc.esb.servicegov.entity.Ida;

@Repository
public class SystemDAOImpl extends HibernateDAO<com.dc.esb.servicegov.entity.System, String> {

}

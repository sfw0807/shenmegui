package com.dc.esb.servicegov.excel.support;

public class Constants {
	
	public static final String MAPPING_FILE_TYPE = "MAPPING";
	
	public static final String SERVICE_FILE_TYPE = "SERVICE";
	
	public static final String INTERFACE_FILE_TYPE = "INTERFACE";

}

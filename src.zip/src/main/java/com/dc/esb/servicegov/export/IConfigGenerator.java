package com.dc.esb.servicegov.export;

import java.io.File;


public interface IConfigGenerator {
	public File generate();
}

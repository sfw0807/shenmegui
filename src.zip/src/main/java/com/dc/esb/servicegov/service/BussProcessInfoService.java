package com.dc.esb.servicegov.service;

import com.dc.esb.servicegov.entity.BussProcessInfo;
import com.dc.esb.servicegov.service.support.BaseService;

public interface BussProcessInfoService extends BaseService<BussProcessInfo, String> {

}

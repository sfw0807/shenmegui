package com.dc.esb.servicegov.service;

import com.dc.esb.servicegov.entity.ContextMappingInfo;
import com.dc.esb.servicegov.service.support.BaseService;

public interface ContextMappingInfoService extends BaseService<ContextMappingInfo, String> {

}

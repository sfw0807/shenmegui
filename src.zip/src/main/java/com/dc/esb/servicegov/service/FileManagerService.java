package com.dc.esb.servicegov.service;

import com.dc.esb.servicegov.entity.FileManager;
import com.dc.esb.servicegov.entity.Ida;
import com.dc.esb.servicegov.service.support.BaseService;

/**
 * Created by Administrator on 2015/7/12.
 */
public interface FileManagerService  extends BaseService<FileManager, String> {
}

package com.dc.esb.servicegov.service;

import com.dc.esb.servicegov.entity.Generator;
import com.dc.esb.servicegov.service.support.BaseService;

public interface GeneratorService extends BaseService<Generator, String> {

}

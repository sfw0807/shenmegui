package com.dc.esb.servicegov.service;

import com.dc.esb.servicegov.entity.IdaProp;
import com.dc.esb.servicegov.service.support.BaseService;

public interface IdaPropService extends BaseService<IdaProp, String>{

}

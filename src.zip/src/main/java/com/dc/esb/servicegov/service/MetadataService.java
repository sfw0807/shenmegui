package com.dc.esb.servicegov.service;

import com.dc.esb.servicegov.entity.Metadata;
import com.dc.esb.servicegov.service.support.BaseService;

public interface MetadataService extends BaseService<Metadata, String>{

}

package com.dc.esb.servicegov.service;

import com.dc.esb.servicegov.entity.MetadataTemplate;
import com.dc.esb.servicegov.service.support.BaseService;

public interface MetadataTemplateService extends BaseService<MetadataTemplate, String> {

}

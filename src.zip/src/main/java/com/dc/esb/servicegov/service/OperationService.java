package com.dc.esb.servicegov.service;

import com.dc.esb.servicegov.entity.Operation;
import com.dc.esb.servicegov.service.support.BaseService;

public interface OperationService extends BaseService<Operation, String> {

}

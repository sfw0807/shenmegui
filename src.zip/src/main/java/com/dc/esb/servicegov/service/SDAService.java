package com.dc.esb.servicegov.service;

import com.dc.esb.servicegov.entity.SDA;
import com.dc.esb.servicegov.service.support.BaseService;

public interface SDAService extends BaseService<SDA, String> {

}

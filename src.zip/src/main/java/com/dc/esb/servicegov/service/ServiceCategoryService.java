package com.dc.esb.servicegov.service;

import com.dc.esb.servicegov.entity.ServiceCategory;
import com.dc.esb.servicegov.service.support.BaseService;


public interface ServiceCategoryService extends BaseService<ServiceCategory, String> {
}

package com.dc.esb.servicegov.service;

import com.dc.esb.servicegov.entity.ServiceHeadHis;
import com.dc.esb.servicegov.service.support.BaseService;

public interface ServiceHeadHisService extends BaseService<ServiceHeadHis, String> {

}

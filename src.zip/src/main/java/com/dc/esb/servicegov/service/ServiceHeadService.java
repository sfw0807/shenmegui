package com.dc.esb.servicegov.service;

import com.dc.esb.servicegov.entity.ServiceHead;
import com.dc.esb.servicegov.service.support.BaseService;

public interface ServiceHeadService extends BaseService<ServiceHead, String> {

}

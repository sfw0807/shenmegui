package com.dc.esb.servicegov.service;

import com.dc.esb.servicegov.entity.ServiceHis;
import com.dc.esb.servicegov.service.support.BaseService;

public interface ServiceHisService extends BaseService<ServiceHis, String> {

}

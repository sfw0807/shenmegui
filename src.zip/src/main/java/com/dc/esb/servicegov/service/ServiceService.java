package com.dc.esb.servicegov.service;

import com.dc.esb.servicegov.dao.support.HibernateDAO;
import com.dc.esb.servicegov.entity.Service;
import com.dc.esb.servicegov.service.support.BaseService;

public interface ServiceService extends BaseService<Service, String>{
}

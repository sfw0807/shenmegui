package com.dc.esb.servicegov.service;

import com.dc.esb.servicegov.entity.WorkItem;
import com.dc.esb.servicegov.entity.WorkItemHandler;
import com.dc.esb.servicegov.service.support.BaseService;

public interface WorkItemHandlerService extends BaseService<WorkItemHandler, String> {

}

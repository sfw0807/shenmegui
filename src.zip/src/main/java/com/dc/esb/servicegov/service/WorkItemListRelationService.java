package com.dc.esb.servicegov.service;

import com.dc.esb.servicegov.entity.WorkItemListRelation;
import com.dc.esb.servicegov.service.support.BaseService;

public interface WorkItemListRelationService extends BaseService<WorkItemListRelation, String> {

}

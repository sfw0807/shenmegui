package com.dc.esb.servicegov.util;

public class AuditUtil {

	public static final String temp = "0";
	public static final String submit = "1";
	public static final String passed = "2";
	public static final String reject = "3";
}